<?php
session_start(); 
?>
<!DOCTYPE html><html>
<head>
<title>Payment Notify</title>
</head>
<body>
<?php
$servername="localhost";
$username="u519960980_try";
$password="k8336042640";
$connection=@mysqli_connect($servername,$username,$password) or die("Could not connect to the localhost");
@mysqli_select_db($connection,'u519960980_try') or die("Could not connect to the database");

	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	foreach ($_POST as $key => $value) {
		$value = urlencode(stripslashes($value));
		$value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i','${1}%0D%0A${3}',$value);// IPN fix
		$req .= "&$key=$value";
	}
	
	// assign posted variables to local variables
	$payment_status	= $_POST['payment_status'];
	$amount         = $_POST['mc_gross'];
	$currency       = $_POST['mc_currency'];
	$trx_id         = $_POST['txn_id'];
	$receiver_email = $_POST['receiver_email'];
	$payer_email    = $_POST['payer_email'];
	$ipnsiteurl     = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $ipnsiteurl);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
	$result = curl_exec($ch);
	curl_close($ch);


if($payment_status=="Completed"&&preg_match("/VERIFIED/i",$result))
{
$sql = "INSERT INTO `u519960980_try`.`donate_amount` (`id`, `amount`, `currency`, `trx_id`, `user_name`) VALUES ('', '$amount', '$currency', '$trx_id', '$payer_email');";
$run = mysqli_query($connection,$sql);
}
else
{
header("Location: index.php");
}
?>
</body>
</html>	