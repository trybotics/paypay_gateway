<?php
$servername="localhost";
$username="u519960980_try";
$password="k8336042640";
$connection=@mysqli_connect($servername,$username,$password) or die("Could not Connect");
@mysqli_select_db($connection,'u519960980_try');
$sql = "CREATE TABLE donate_amount (id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY, amount VARCHAR(30) NOT NULL, currency VARCHAR(30) NOT NULL, trx_id VARCHAR(50) NOT NULL, user_name VARCHAR(50) NOT NULL )";
        
 if ($connection->query($sql) === TRUE) 
 {
    echo "Table user created successfully";
  }
 else
  {
    echo "Error creating table: " . $connection->error;
  }
?>