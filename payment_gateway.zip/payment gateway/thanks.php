<?php
session_start(); 
?>
<!DOCTYPE html><html>
<head>
<title>Payment Successful!</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<?php
$servername="localhost";
$username="u519960980_try";
$password="k8336042640";
$connection=@mysqli_connect($servername,$username,$password) or die("Could not connect to the localhost");
@mysqli_select_db($connection,'u519960980_try') or die("Could not connect to the database");

	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	foreach ($_POST as $key => $value) {
		$value = urlencode(stripslashes($value));
		$value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i','${1}%0D%0A${3}',$value);// IPN fix
		$req .= "&$key=$value";
	}
	
	// assign posted variables to local variables
        $paypalurl = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
	$data['payment_status'] 	= $_POST['payment_status'];
	$data['payment_amount'] 	= $_POST['mc_gross'];
	$data['payment_currency']	= $_POST['mc_currency'];
	$data['txn_id']			= $_POST['txn_id'];
	$data['receiver_email'] 	= $_POST['receiver_email'];
	$data['payer_email'] 		= $_POST['payer_email'];
		
	$ipnsiteurl=$paypalurl;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $ipnsiteurl);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
	$result = curl_exec($ch);
	curl_close($ch);


if($data['payment_status']=="Completed"&&preg_match("/VERIFIED/i",$result))
{
echo "<center><h1>Payment successfully!</h1></center>";
echo "<center><h2>Thank You ".$data['payer_email']." For Donating ".$data['payment_currency']." ".$data['payment_amount']."</h2></center>";
}
else if (isset($_POST["txn_id"]))
{
echo "<center><h2>Your donation was failed, please try again</h2><br></center>";
echo "<center><a href='http://try.16mb.com'>Go to home page to pay again</a></center><br>";
}
// table
$sql = "SELECT id, amount, currency, trx_id, user_name FROM `donate_amount`";
$result = $connection->query($sql);

if ($result->num_rows > 0) 
{
   echo "<center><h2>List People Who Have Donated Money</h2></center>";
   echo "<center><table><tr><th>ID</th><th>User Name</th><th>Transaction_ID</th><th>Currency</th><th>Amount</th></tr>";
   // output data of each row
   while($row = $result->fetch_assoc()) 
   {
       echo "<tr><td>" . $row["id"]. "</td><td>".$row["user_name"]."</td><td>".$row["trx_id"]."</td><td> " . $row["currency"]. "</td><td>" . $row["amount"]. "</td></tr>";
   }
   echo "</table></center>";
} else 
{
    echo "Sorry no results";
}
echo "<br><center><a href='http://try.16mb.com'>Go to home page</a></center>";
?>
</body>
</html>	