<!DOCTYPE html>
<html>
<head>
	<title>DONATE USING PAYPAL</title>
</head>
<body style="margin-top: 50px;">
<center><div style="border: blue solid 1px;width:340px;padding: 20px;">
<img src="t1.jpg" style="margin-top: 50px;border:solid 5px;"><br><br>
<h1>Donate Money</h1>
<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

  <!-- Identify your business so that you can collect the payments. -->
  <input type="hidden" name="business" value="trybotics@business.com">

  <!-- Specify a Buy Now button. -->
  <input type="hidden" name="cmd" value="_xclick">

  <!-- Specify details about the item that buyers will purchase. -->
  <input type="hidden" name="item_name" value="Donating Money To trybotics">
  <input type="text" name="amount" placeholder="Amount" required><br><br>
  <input list="currency_code" name="currency_code" placeholder="Select your Currency" required>
  <datalist id="currency_code">
    <option value="Rupees">
    <option value="USD">
  </datalist><br><br>
<input type="hidden" name="custom" value="1"/>
<input type="hidden" name="item_number" value="1"/>
<!--Specify the Pages for Successful payment & failed Payment-->

<input type="hidden" name="return" value="http://try.16mb.com/thanks.php"/>
<input type="hidden" name="notify_url" value="http://try.16mb.com/payment_successful.php"/>
<input type="hidden" name="cancel_return" value="http://try.16mb.com/payment_cancel.php"/>
  <!-- Display the payment button. -->
<input type="image" name="submit" src="p_d.png" height="50" width="150" alt="Donate Now">

</form>
</div></center>
</body>
</html>