<?php
session_start();
?>
<!DOCTYPE html><html>
<head>
<title>Payment Successful!</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<?php
$servername="localhost";
$username="u519960980_try";
$password="k8336042640";
$connection=@mysqli_connect($servername,$username,$password) or die("Could not connect to the localhost");
@mysqli_select_db($connection,'u519960980_try') or die("Could not connect to the database");

//Getting payment details from paypal

//This code required for IPN Notifications on PayPal
        $amount = $_POST["payment_gross"];
        $currency = $_POST["mc_currency"];
        $trx_id    = $_POST["txn_id"];
        $payer_email = $_POST["payer_email"];
        $payment_status   = $_POST["payment_status"];
//echo "txn_id =".$trx_id."<br>";
//echo "payment_gross =".$amount."<br>";
//echo "mc_currency =".$currency."<br>";
//echo "payer_email =".$payer_email."<br>";
//echo "payment_status = ".$payment_status."<br>";
//inserting the payment to table


if($payment_status=="Completed")
{
echo "<center><h2>Welcome:" .$payer_email. "<br><br>" . "Your have Donated ".$amount." ".$currency." successfully!</h2></center>";
echo "<center><h2>Thank You For Donating</h2></center>";
echo "<center><h2>People Who Have Donated Money</h2></center>";
}
else 
{
echo "<center><h2>Welcome Guest, Donation is failed</h2><br></center>";
echo "<center><a href='http://try.16mb.com'>Go to your Account</a></center>";
}
// table
$sql = "SELECT id, amount, currency, trx_id, user_name FROM `donate_amount`";
$result = $connection->query($sql);

if ($result->num_rows > 0) 
{
   echo "<center><table><tr><th>ID</th><th>Amount</th><th>Currency</th><th>Transaction_ID</th><th>User_Name</th></tr>";
   // output data of each row
   while($row = $result->fetch_assoc()) 
   {
       echo "<tr><td>" . $row["id"]. "</td><td>" . $row["amount"]. "</td><td> " . $row["currency"]. "</td><td>".$row["trx_id"]."</td><td>".$row["user_name"]."</td></tr>";
    }
    echo "</table></center>";
} else 
{
    echo "Sorry no results";
}
echo "<br><center><a href='http://try.16mb.com'>Go to home page</a></center>";
?>
</body>
</html>	