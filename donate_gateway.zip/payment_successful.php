<?php
session_start();
?>
<!DOCTYPE html><html>
<head>
<title>Payment Successful!</title>
</head>
<body>
<?php
$servername="localhost";
$username="u519960980_try";
$password="k8336042640";
$connection=@mysqli_connect($servername,$username,$password) or die("Could not connect to the localhost");
@mysqli_select_db($connection,'u519960980_try') or die("Could not connect to the database");

//Getting payment details from paypal

//This code required for IPN Notifications on PayPal
        $amount = $_POST["payment_gross"];
        $currency = $_POST["mc_currency"];
        $trx_id    = $_POST["txn_id"];
        $payer_email = $_POST["payer_email"];
        $payment_status   = $_POST["payment_status"];
//echo "txn_id =".$trx_id."<br>";
//echo "payment_gross =".$amount."<br>";
//echo "mc_currency =".$currency."<br>";
//echo "payer_email =".$payer_email."<br>";
//echo "payment_status = ".$payment_status."<br>";
//inserting the payment to table

$sql = "INSERT INTO `u519960980_try`.`donate_amount` (`id`, `amount`, `currency`, `trx_id`, `user_name`) VALUES ('', '$amount', '$currency', '$trx_id', '$payer_email');";

$run = mysqli_query($connection,$sql);

if($payment_status=="Completed")
{
echo "<h2>Welcome:" .$payer_email. "<br>" . "Your have Donated successfully!</h2>";
echo "<a href='http://try.16mb.com/donate_gateway'>Go to your Account</a>";
}
else 
{
echo "<h2>Welcome Guest, Donation is failed</h2><br>";
echo "<a href='http://try.16mb.com/donate_gateway'>Go to Back to shop</a>";
}
?>
</body>
</html>	