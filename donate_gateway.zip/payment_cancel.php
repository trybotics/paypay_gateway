<!DOCTYPE html><html>
<head>
<title>Donation Canceled!</title>
</head>
<body>
<h2>Your Donation Payment is Successfully Canceled!</h2>
<h3><a href="http://try.16mb.com/donate_gateway">Go To The Home Page</a></h3>
</body>
</html>